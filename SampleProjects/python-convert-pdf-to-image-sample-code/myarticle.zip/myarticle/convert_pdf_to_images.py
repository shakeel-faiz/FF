# Import required libraries
from pdf2image import convert_from_path
from PIL import Image

# Specify the path to the PDF file
# pdf_path = 'yourfile.pdf'
pdf_path = r'C:\Users\Family74\Desktop\Desk\sample\sample.pdf'

# Convert PDF to a list of images
try:
    images = convert_from_path(pdf_path)
    
    # Save each page as a separate JPEG image
    for i, image in enumerate(images):
        image.save(f'page_{i + 1}.jpg', 'JPEG')
        print(f"Saved page_{i + 1}.jpg")
except Exception as e:
    print(f"An error occurred: {e}")
